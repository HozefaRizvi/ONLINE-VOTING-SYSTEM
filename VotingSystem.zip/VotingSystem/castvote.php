<?php

$uname = $_POST['uname'];
$ans   = $_POST['vote1'];
$con = mysqli_connect('localhost','root','','votingsystem');
if($ans == "PTI")
{
    $sql = mysqli_query($con,"UPDATE loginvoter SET vote = '$ans' WHERE username = '$uname'");
    header('Location:VoterHome.html');
}
else if($ans == "PMLN")
{
    $sql = mysqli_query($con,"UPDATE loginvoter SET vote = '$ans' WHERE username = '$uname'");
    header('Location:VoterHome.html');
}
else if($ans == "PMLQ")
{
    $sql = mysqli_query($con,"UPDATE loginvoter SET vote = '$ans' WHERE username = '$uname'");
    header('Location:VoterHome.html');
}
else
{
    header('Location:VoterHome.html');
}

?>