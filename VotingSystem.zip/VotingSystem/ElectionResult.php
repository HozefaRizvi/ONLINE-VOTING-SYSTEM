<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Election Result</title>
    <style>
      #table1
      {
        background-color:#C2C0A6;
          height:80px;
          width:270px;
          position:relative;
          top:170px;
          left:160px;
          text-align:center;
      }
     #voterecieve h1
      {
        position: relative;
        top:90px;
      }
    </style>
</head>
<body>
 <div id="voterecieve">
   <h1 >Congratulation following party has won the election</h1>
     <?php
        $con = mysqli_connect('localhost','root','','votingsystem'); 
        $sql = mysqli_query($con,"SELECT vote , max(vote) FROM loginvoter ");
        echo "<table border = 1 cellpadding = 30 cellspacing  = 0 id = 'table1'>";
        echo "<tr>";
        echo "<td>PARTY WON</td>";

        while($re = mysqli_fetch_array($sql))
        {
            echo "<td>".$re['max(vote)']."</td>";
            echo "</tr>";
        }
        echo "</table>";
     ?>
 </div>
</body>
</html>