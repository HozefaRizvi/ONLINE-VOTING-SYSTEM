<?php

$uname = $_POST['UserNameadmin'];
$pass = $_POST['password'];
//Database Connectivity

$con = mysqli_connect('localhost','root','','votingsystem');
$sql  = mysqli_query($con,"SELECT*FROM loginadmin where username = '$uname' AND password = '$pass'");
$fetch = mysqli_fetch_array($sql);

if($fetch['username'] == $uname && $fetch['password'] == $pass)
{
    header("Location: adminHome.html");
}
else
{
          header("Location: login.html");
}
?>