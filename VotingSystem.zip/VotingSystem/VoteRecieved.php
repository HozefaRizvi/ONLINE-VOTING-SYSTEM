<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Votes Recieved</title>
    <style>
      #table1
      {
        background-color:#C2C0A6;
          height:300px;
          width:500px;
          position:relative;
          top:60px;
          left:40px;
          text-align:center;
      }
    </style>
</head>
<body>
 <div id="voterecieve">
     <?php
        $con = mysqli_connect('localhost','root','','votingsystem'); 
        $sql = mysqli_query($con,"SELECT vote , count(*) FROM loginvoter GROUP BY  vote");
        echo "<table border = 1 cellpadding = 30 cellspacing  = 0 id = 'table1'>";
        echo "<tr>";
        echo "<td>VOTES</td>";
        echo "<td>VOTES RECIEVED</td>";
        echo "</tr>";
        while($re = mysqli_fetch_array($sql))
        {
            echo "<tr>";
            echo "<td>".$re['vote']."</td>";
            echo "<td>".$re['count(*)']."</td>";
            echo "</tr>";
        }
        echo "</table>";
     ?>
 </div>
</body>
</html>