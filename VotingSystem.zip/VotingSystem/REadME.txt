TO RUN THIS PROJECT YOU HAVE TO DO FOLLOWING THINGS:

STEP 1:

Download the project from the github and unzip in Local:C/xampp/htdocs.

STEP 2:

There is a databse folder inside the project and inside it there is databse votingsystem.sql
Open localhost/phpmyadmin and import this sql file

STEP 3:
 
Run the login.html file in your favorite browser 

STEP 4: 

Admin login info: 

username: admin
password: admin


