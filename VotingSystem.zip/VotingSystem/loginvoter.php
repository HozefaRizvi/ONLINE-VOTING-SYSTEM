<?php

$uname = $_POST['UserName'];
$cnic = $_POST['CNIC'];
//Database Connectivity

$con = mysqli_connect('localhost','root','','votingsystem');
$sql  = mysqli_query($con,"SELECT*FROM loginvoter where username = '$uname' AND cnic = '$cnic'");
$fetch = mysqli_fetch_array($sql);

if($fetch['username'] == $uname && $fetch['cnic'] == $cnic)
{
    header("Location: VoterHome.html");
}
else
{
          header("Location: login.html");
}

?>