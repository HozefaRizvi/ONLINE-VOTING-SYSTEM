<?php


$uname = $_POST['UserNameS'];
$cnic = $_POST['CNICS'];
//Database Connectivity
$con = mysqli_connect('localhost','root','','votingsystem');
$sql  = mysqli_query($con,"INSERT INTO loginvoter values('', '$uname','$cnic', '')");
header('Location: login.html');
?>

